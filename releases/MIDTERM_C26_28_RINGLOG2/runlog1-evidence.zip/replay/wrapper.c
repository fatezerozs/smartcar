#include "vision_midterm.c"
__declspec(dllexport) void replay_reset(void){vision_midterm_reset();vision_midterm_route_enable(0);}
__declspec(dllexport) void replay_frame(const uint8_t *gray,int enabled,int repeats,int *values){
 static uint8_t binary[VISION_WIDTH*VISION_HEIGHT];vision_result_t r={0};
 vision_midterm_route_enable((uint8_t)enabled);
 for(int i=0;i<repeats;++i)vision_midterm_process(gray,binary,&r);
 values[0]=r.roundabout_state;values[1]=r.valid;values[2]=r.confidence;
 values[3]=r.entry_guide_rows;values[4]=r.path_fallback;values[5]=reference_ring.island_visible;
 values[6]=reference_ring.island_lost_frames;values[7]=reference_ring.clear_votes;
 values[8]=r.camera_width90;values[9]=reference_ring.path_rejects;
 for(int i=0;i<12;++i)values[10+i]=ring_diag[i];
}
