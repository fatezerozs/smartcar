#ifndef VISION_RING_ENTRY_H
#define VISION_RING_ENTRY_H
/* A confirmed tangent island needs an entry target, rather than continuing
 * to center the straight corridor. Keep measured boundaries/widths untouched.
 * The guide exists only with a CURRENT island and CURRENT white clearance. */
static void reference_ring_entry_guide(const uint8_t *binary,vision_result_t *out,float weight_sum)
{
    float correction=0;
    unsigned rows=0;
    if(!out->valid||reference_ring.state!=1||!reference_ring.island_visible)return;
    for(int y=VISION_ROI_TOP;y<=VISION_ROI_BOTTOM;++y){
        int flags=out->row_flags[y],width=out->row_width[y],point,margin,good=1;
        float center,progress,weight;
        if(flags<1||flags>3||width<VISION_MIN_WIDTH)continue;
        center=flags==1?out->left[y]+(width-1)*.5f:
            flags==2?out->right[y]-(width-1)*.5f:(out->left[y]+out->right[y])*.5f;
        if(center<0||center>VISION_WIDTH-1)continue;
        /* Current island lower cap advances the entry target toward the car.
         * No elapsed-time turn schedule or old-frame pixels are used. */
        progress=(reference_ring.island_bottom+12.0f-y)/32.0f;
        if(progress<=0)continue;if(progress>1)progress=1;
        point=(int)(center+.5f);margin=(width+3)/4;
        if(point-margin<0||point+margin>=VISION_WIDTH)continue;
        for(int x=point-margin;x<=point+margin;++x)
            if(!binary[y*VISION_WIDTH+x]){good=0;break;}
        if(!good)continue;
        /* Advance only through CURRENT white clearance. A fixed fraction can
         * be too weak to leave a tangent main line, or reject a useful smaller
         * move when the full fraction is obstructed. Stop at the first dark
         * pixel; never jump across an obstacle to a different white branch. */
        for(int step=1;step<=(int)(width*.5f*progress);++step){
            int next=point+reference_ring.side,clear=1;
            if(next-margin<0||next+margin>=VISION_WIDTH)break;
            for(int x=next-margin;x<=next+margin;++x)
                if(!binary[y*VISION_WIDTH+x]){clear=0;break;}
            if(!clear)break;
            point=next;
        }
        if(point==(int)(center+.5f))continue;
        /* A central half-road-width strip around the candidate must be
         * current white, as must the whole lateral transition from center. */
        for(int x=point-margin;x<=point+margin;++x)if(!binary[y*VISION_WIDTH+x]){good=0;break;}
        if(!good)continue;
        {int a=(int)(center+.5f),b=point;if(a>b){int t=a;a=b;b=t;}
         for(int x=a;x<=b;++x)if(!binary[y*VISION_WIDTH+x]){good=0;break;}}
        if(!good)continue;
        out->entry_guide[y]=(uint8_t)point;++rows;
        weight=y>=60&&y<=90?14.0f:(y>=40?8.0f:2.0f);
        if(flags!=3)weight*=.5f;
        correction+=weight*(point-center);
    }
    /* Replace independent offsets with one current connected entry path. */
    float legacy_correction=correction;
    uint8_t legacy_guide[VISION_HEIGHT];
    unsigned legacy_rows=rows;
    memcpy(legacy_guide,out->entry_guide,sizeof(legacy_guide));
    if(rows>=12){
        float near=0;int near_n=0;
        for(int y=VISION_ROI_BOTTOM;y>VISION_ROI_BOTTOM-8;--y)
            if(out->row_flags[y]>=1&&out->row_flags[y]<=3){
                if(!near_n)near=out->center[y];++near_n;
            }
        if(near_n>=6){
            /* Anchor to the vehicle reference within the current near strip,
             * before the island-side width model biases its center. */
            near=(VISION_WIDTH-1)*VISION_AXIS_NEAR_X;
            reference_ring_bridge_prepare(binary,near,1,out->entry_guide);
            int selected=-1,selected_guide=0;float best=0;
            for(int y=VISION_ROI_TOP+7;y<=VISION_ROI_BOTTOM-11;++y){
                int guide=out->entry_guide[y];
                float shift=(float)(reference_ring.side*(guide-(int)out->center[y]));
                if(guide>=VISION_WIDTH||shift<1||!reference_ring_bridge(y,(float)guide))continue;
                float score=shift/(learned_width[y]+1)*(y>=60&&y<=90?1.0f:.7f);
                if(score>best){best=score;selected=y;selected_guide=guide;}
            }
            if(selected>=0&&reference_ring_bridge(selected,(float)selected_guide)){
                int y=selected;
                memset(out->entry_guide,VISION_INVALID_X,sizeof(out->entry_guide));
                rows=0;correction=0;
                for(int row=y;row<=VISION_ROI_BOTTOM;++row)
                    if(out->row_flags[row]>=1&&out->row_flags[row]<=3){
                        out->entry_guide[row]=ring_bridge_points[row];++rows;
                        float w=row>=60&&row<=90?14.0f:(row>=40?8.0f:2.0f);
                        if(out->row_flags[row]!=3)w*=.5f;
                        correction+=w*((int)ring_bridge_points[row]-out->center[row]);
                    }
                if(rows<12)goto legacy_entry;
                out->entry_guide_rows=(uint8_t)rows;
                out->error_px+=correction/weight_sum;
                out->entry_path_valid=1;return;
            }
        }
    }
legacy_entry:
    /* Optional planner failure must not erase the existing usable guide. */
    if(legacy_rows>=12){
        memcpy(out->entry_guide,legacy_guide,sizeof(legacy_guide));
        out->entry_guide_rows=(uint8_t)legacy_rows;
        out->error_px+=legacy_correction/weight_sum;
    } else memset(out->entry_guide,VISION_INVALID_X,sizeof(out->entry_guide));
}
#endif
