from pathlib import Path
import ctypes,json,zlib,struct,csv,sys
folder=Path('recordings/dap-export-20261107-005341-808450/decoded')
rows=list(csv.DictReader((folder/'metrics.csv').open(encoding='utf-8-sig')))
name=sys.argv[1];dll=ctypes.CDLL(str(Path('.build/ring-replay',name+'.dll').resolve()));out=[]
for run in [2,3,4]:
 dll.replay_reset();first=True
 for p in sorted((folder/'frames').glob(f'run{run:03d}*.json')):
  j=json.loads(p.read_text());near=min([r for r in rows if int(r['run'])==run],key=lambda r:abs(int(r['ms'])-j['ms']))
  if near['state']!='1':continue
  b=p.with_suffix('.png').read_bytes();at=8;z=b''
  while at<len(b):
   n=struct.unpack_from('>I',b,at)[0]
   if b[at+4:at+8]==b'IDAT':z+=b[at+8:at+8+n]
   at+=n+12
  raw=zlib.decompress(z);gray=bytearray()
  for y in range(60):
   row=b''.join(bytes([v,v]) for v in raw[y*95+1:(y+1)*95]);gray+=row+row
  a=(ctypes.c_ubyte*len(gray)).from_buffer(gray);v=(ctypes.c_int*22)()
  if first:dll.replay_frame(a,0,10,v);first=False
  dll.replay_frame(a,1,25,v)
  out.append({'run':run,'ms':j['ms'],'field_ring':int(near['ring']),'v':list(v)})
Path('.build/ring-replay',name+'.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
for run in [2,3,4]:
 r=[x for x in out if x['run']==run];prev=None;changes=[]
 for x in r:
  key=(x['v'][0],x['v'][1])
  if key!=prev or x['v'][20]:changes.append(x)
  prev=key
 print(json.dumps({'run':run,'states':sorted(set(x['v'][0] for x in r)),'changes':changes},ensure_ascii=True))
