@echo off
call tools\msvc_env.cmd
cl /nologo /utf-8 /std:c11 /W4 /WX /O2 /LD /DVISION_ROUTE_SWITCH=1 /I.build\ring-replay\code .build\ring-replay\wrapper.c /Fo.build\ring-replay\ /Fe.build\ring-replay\baseline.dll
exit /b %errorlevel%
