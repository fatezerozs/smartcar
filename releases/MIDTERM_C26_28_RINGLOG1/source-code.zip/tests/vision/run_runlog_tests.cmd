@echo off
call tools\msvc_env.cmd
if errorlevel 1 exit /b 2
if not exist .build\runlog-test mkdir .build\runlog-test
cl /nologo /utf-8 /std:c11 /W4 /WX /Od /Zi /fsanitize=address /DRUNLOG_HOST=1 /DVISION_ROUTE_SWITCH=1 /Itests\vision\stubs /Idemo\code tests\vision\test_runlog_core.c demo\code\vision_runlog.c /Fo.build\runlog-test\ /Fe.build\runlog-test\test_core.exe
if errorlevel 1 exit /b 2
.build\runlog-test\test_core.exe .build\runlog-test\fixture.bin
if errorlevel 1 exit /b 1
cl /nologo /utf-8 /std:c11 /W4 /WX /Od /Zi /fsanitize=address /Itests\vision\stubs /Idemo\code /Ilibraries\components\fatfs\source tests\vision\test_runlog_storage.c /Fo.build\runlog-test\ /Fe.build\runlog-test\test_storage.exe
if errorlevel 1 exit /b 2
.build\runlog-test\test_storage.exe
exit /b %errorlevel%
