#include "vision_runlog.h"
#include "ff.h"
#include <stdio.h>
#include <string.h>
static FATFS fs;
static FIL file;
static int mounted,opened;
static uint32_t next_name;
void runlog_store_poll(const uint8_t *data,uint32_t length,volatile runlog_status_t *s)
{
    FRESULT r;UINT written;uint32_t n;
    s->sd_state=1;
    if(!mounted){r=f_mount(&fs,"2:",1);if(r!=FR_OK)goto fault;mounted=1;}
    if(!opened){
        char name[16];
        if(!s->filename[0]){
            do{
                if(next_name>9999999U){r=FR_DENIED;goto fault;}
                (void)snprintf(name,sizeof(name),"2:/R%07lu.BIN",(unsigned long)next_name++);
                r=f_open(&file,name,FA_WRITE|FA_CREATE_NEW);
            }while(r==FR_EXIST);
            if(r!=FR_OK)goto fault;
            memcpy((void *)s->filename,name,sizeof(name));
        }else{
            memcpy(name,(const void *)s->filename,sizeof(name));
            r=f_open(&file,name,FA_WRITE);if(r!=FR_OK)goto fault;
            r=f_lseek(&file,s->flushed);if(r!=FR_OK)goto fault;
        }
        opened=1;
    }
    n=length-s->flushed;if(n>32768U)n=32768U;
    r=f_write(&file,data+s->flushed,n,&written);if(r!=FR_OK)goto fault;
    if(written!=n){r=FR_DISK_ERR;goto fault;}s->flushed+=written;
    if(s->flushed==length){
        r=f_sync(&file);if(r!=FR_OK)goto fault;
        r=f_close(&file);if(r!=FR_OK)goto fault;opened=0;s->sd_state=2;
    }
    return;
fault:
    /* Keep RAM and the original media error; no reformat/retry/drive veto. */
    s->sd_state=3;s->sd_error=(uint32_t)r;
}
