/* Adapted from main 00bb7a47 demo/sd_performance/board.c and Recorder pins.
 * Only called after C26 OFF. USDHC1 1-bit preserves D16/D17 radio and C30 servo. */
#include "main.h"
#include "vision_runlog.h"
#include "fsl_sd.h"
#include "fsl_sdmmc_host.h"
#include "ff.h"
#include "diskio.h"
#include <string.h>
#include <stdio.h>
AT_SDRAM_NONCACHE_SECTION_ALIGN(sd_card_t g_sd,64);
AT_SDRAM_NONCACHE_SECTION_ALIGN(static sdmmchost_t host,64);
AT_SDRAM_NONCACHE_SECTION_ALIGN(static uint32_t descriptors[128],64);
AT_SDRAM_NONCACHE_SECTION_ALIGN(static uint8_t bounce[32768],64);
static int configured,initialized,failed;
static bool present(void){return gpio_get_level(D4)==0;}
static void power(bool on){gpio_set_level(B23,on?GPIO_LOW:GPIO_HIGH);}
static void pads(uint32_t hz)
{
    (void)hz;
    IOMUXC_SetPinConfig(IOMUXC_GPIO_SD_B0_00_USDHC1_CMD,0x170F9U);
    IOMUXC_SetPinConfig(IOMUXC_GPIO_SD_B0_01_USDHC1_CLK,0x10F9U);
    IOMUXC_SetPinConfig(IOMUXC_GPIO_SD_B0_02_USDHC1_DATA0,0x170F9U);
}
static void configure(void)
{
    static sd_detect_card_t cd;static sd_io_voltage_t voltage;
    /* Do not call sdhc_iomuxc/BOARD_SD_Config: they claim radio DATA2/3 and servo VSELECT. */
    gpio_init(B23,GPO,GPIO_LOW,GPO_PUSH_PULL);gpio_init(D4,GPI,GPIO_HIGH,GPI_PULL_UP);
    gpio_init(D15,GPI,GPIO_HIGH,GPI_PULL_UP);
    IOMUXC_SetPinMux(IOMUXC_GPIO_SD_B0_00_USDHC1_CMD,0);
    IOMUXC_SetPinMux(IOMUXC_GPIO_SD_B0_01_USDHC1_CLK,0);
    IOMUXC_SetPinMux(IOMUXC_GPIO_SD_B0_02_USDHC1_DATA0,0);pads(0);
    CLOCK_SetDiv(kCLOCK_Usdhc1Div,1);CLOCK_SetMux(kCLOCK_Usdhc1Mux,1);
    host.hostController.base=USDHC1;
    host.hostController.sourceClock_Hz=CLOCK_GetFreq(kCLOCK_SysPllPfd0Clk)/2U;
    host.dmaDesBuffer=descriptors;host.dmaDesBufferWordsNum=128;
    host.enableCacheControl=kSDMMCHOST_CacheControlRWBuffer;
    cd.type=kSD_DetectCardByGpioCD;cd.cardDetected=present;cd.cdDebounce_ms=100;
    voltage.type=kSD_IOVoltageCtrlNotSupport;
    g_sd.host=&host;g_sd.usrParam.cd=&cd;g_sd.usrParam.pwr=power;
    g_sd.usrParam.ioStrength=pads;g_sd.usrParam.ioVoltage=&voltage;g_sd.usrParam.maxFreq=25000000;
    /* The standalone reference enabled this in its main(). Our OSA uses the
     * cycle counter for SDK SD busy-poll delays; initialize it here too. */
    CoreDebug->DEMCR|=CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CTRL|=DWT_CTRL_CYCCNTENA_Msk;
    NVIC_SetPriority(USDHC1_IRQn,5);configured=1;
}
DSTATUS disk_status(BYTE d)
{return d!=2||!initialized||failed?STA_NOINIT:!present()?STA_NOINIT|STA_NODISK:0;}
DSTATUS disk_initialize(BYTE d)
{
    if(d!=2||failed)return STA_NOINIT;
    if(!configured)configure();if(!present())return STA_NOINIT|STA_NODISK;
    if(initialized)return 0;
    if(SD_Init(&g_sd)!=kStatus_Success||g_sd.blockSize!=512U||
       g_sd.busClock_Hz>25000000U||(USDHC1->PROT_CTRL&USDHC_PROT_CTRL_DTW_MASK)){
        failed=1;return STA_NOINIT;
    }
    initialized=1;return 0;
}
static DRESULT transfer(BYTE d,BYTE *out,const BYTE *in,LBA_t sec,UINT count)
{
    if(!count||d!=2)return RES_PARERR;if(disk_status(d))return RES_NOTRDY;
    if(sec>=g_sd.blockCount||count>g_sd.blockCount-sec)return RES_PARERR;
    while(count){UINT n=count>64?64:count;status_t r;
        if(in){memcpy(bounce,in,n*512U);r=SD_WriteBlocks(&g_sd,bounce,sec,n);}
        else r=SD_ReadBlocks(&g_sd,bounce,sec,n);
        if(r!=kStatus_Success||!present()){failed=1;return RES_ERROR;}
        if(out){memcpy(out,bounce,n*512U);out+=n*512U;}
        if(in)in+=n*512U;sec+=n;count-=n;
    }
    return RES_OK;
}
DRESULT disk_read(BYTE d,BYTE *p,LBA_t sec,UINT n){return transfer(d,p,NULL,sec,n);}
DRESULT disk_write(BYTE d,const BYTE *p,LBA_t sec,UINT n){return transfer(d,NULL,p,sec,n);}
DRESULT disk_ioctl(BYTE d,BYTE cmd,void *p)
{
    if(disk_status(d))return RES_NOTRDY;
    switch(cmd){
    case CTRL_SYNC:
        if(SD_PollingCardStatusBusy(&g_sd,1000)==kStatus_SDMMC_CardStatusIdle)return RES_OK;
        failed=1;return RES_ERROR;
    case GET_SECTOR_COUNT:if(p){*(LBA_t *)p=g_sd.blockCount;return RES_OK;}break;
    case GET_SECTOR_SIZE:if(p){*(WORD *)p=512;return RES_OK;}break;
    case GET_BLOCK_SIZE:if(p){*(DWORD *)p=g_sd.csd.eraseSectorSize+1;return RES_OK;}break;
    default:break;
    }
    return RES_PARERR;
}
void runlog_publish(const void *data,uint32_t n)
{
    /* Descriptor is in DTCM. Clean cached SDRAM before debugger bus reads. */
    SCB_CleanDCache_by_Addr((uint32_t *)(uintptr_t)data,(int32_t)((n+63U)&~63U));__DSB();
}
