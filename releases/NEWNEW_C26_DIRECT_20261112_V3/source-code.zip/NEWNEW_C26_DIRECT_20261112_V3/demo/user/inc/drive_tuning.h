#ifndef DRIVE_TUNING_H
#define DRIVE_TUNING_H
/* Phase2 DISTANCE_SCALE_CHECK: two reported 1m push averages, candidate scale. */
#define TARGET_SPEED_MPS 1.0f
#define LEFT_COUNTS_PER_METER 11394.0f
#define RIGHT_COUNTS_PER_METER 11389.0f
#define CONTROL_PERIOD_S .010f
#define STEER_ANGLE_PER_PIXEL .22f
#define STEER_ERROR_DEADBAND_PX 1.0f
typedef struct { float filtered_us,command_us; } servo_smoother_t;
static inline float servo_smooth_step(servo_smoother_t *s,float requested,int enabled)
{
    float delta;
    if(!enabled){s->filtered_us=s->command_us=1550.0f;return 1550.0f;}
    if(requested<1430)requested=1430;if(requested>1670)requested=1670;
    s->filtered_us+=.25f*(requested-s->filtered_us);
    delta=s->filtered_us-s->command_us;
    if(delta>20)delta=20;if(delta<-20)delta=-20;
    if(delta>2||delta<-2)s->command_us+=delta;
    return s->command_us;
}
#endif
