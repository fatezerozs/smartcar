param(
    [Parameter(Mandatory=$true)][ValidatePattern('^COM[0-9]+$')][string]$Port,
    [string]$PriorCapture='',
    [string]$OutputRoot=(Join-Path (Split-Path $PSScriptRoot -Parent) 'recordings')
)
# RX ONLY. Wait behind an existing recorder; reconnect after USB loss.
# Rotate files every 30 minutes WITHOUT closing a working serial port.
# No fixed expiry: create STOP in this session directory to finish.
$ErrorActionPreference='Stop'
$captureDirectory=Join-Path $OutputRoot ('serial-'+$Port+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss-ffffff'))
New-Item -ItemType Directory -Path $captureDirectory | Out-Null
Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $captureDirectory 'listener-source.ps1')
$captureStop=Join-Path $captureDirectory 'STOP'
$captureMetaPath=Join-Path $captureDirectory 'session.json'
$captureClock=[Diagnostics.Stopwatch]::StartNew()
$captureMeta=[ordered]@{port=$Port;baud=115200;receive_only=$true;dtr=$false;rts=$false;
    started_utc=[DateTime]::UtcNow.ToString('o');state='waiting_for_port';bytes=0;
    prior_capture=$PriorCapture;segments=0;connections=0;reconnect=$true;fixed_expiry=$false;
    rotation_seconds=1800;raw_bytes_unfiltered=$true;stop_file='STOP'}
$captureTimes=[IO.StreamWriter]::new((Join-Path $captureDirectory 'chunks.csv'),$false,[Text.UTF8Encoding]::new($false))
$captureEvents=[IO.StreamWriter]::new((Join-Path $captureDirectory 'events.jsonl'),$false,[Text.UTF8Encoding]::new($false))
$captureTimes.WriteLine('host_utc,elapsed_ms,segment,segment_offset,session_offset,bytes')
$captureBuffer=[byte[]]::new(65536)
$captureData=$null;$capturePort=$null;$captureSegment=-1;$captureSegmentOffset=[long]0
$captureSegmentStarted=[long]0;$captureLastFlush=[long]0;$captureLastStatus=[long]0
$captureLastError=''
function Save-CaptureStatus {
    [IO.File]::WriteAllText($captureMetaPath,($captureMeta|ConvertTo-Json -Depth 4),[Text.UTF8Encoding]::new($false))
}
function Add-CaptureEvent([string]$Kind,[string]$Detail) {
    $captureEvents.WriteLine((@{host_utc=[DateTime]::UtcNow.ToString('o');elapsed_ms=$captureClock.ElapsedMilliseconds;kind=$Kind;detail=$Detail}|ConvertTo-Json -Compress))
    $captureEvents.Flush()
}
function Close-CaptureSegment {
    if($script:captureData){
        $script:captureData.Dispose();$script:captureData=$null
        Add-CaptureEvent 'segment_closed' ('segment='+$script:captureSegment+' bytes='+$script:captureSegmentOffset)
    }
}
function Open-CaptureSegment {
    Close-CaptureSegment
    ++$script:captureSegment
    $script:captureSegmentOffset=[long]0
    $capturePath=Join-Path $captureDirectory ('{0:D6}.rx.bin' -f $script:captureSegment)
    $script:captureData=[IO.FileStream]::new($capturePath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)
    $script:captureSegmentStarted=$captureClock.ElapsedMilliseconds
    $captureMeta.segments=$script:captureSegment+1
    Add-CaptureEvent 'segment_opened' ([IO.Path]::GetFileName($capturePath))
}
Save-CaptureStatus
Write-Output ('CONTINUOUS RX SUPERVISOR '+$Port+': '+$captureDirectory)
Add-CaptureEvent 'started' ('prior_capture='+$PriorCapture)
try {
    while(-not(Test-Path -LiteralPath $captureStop)) {
        try {
            $capturePort=[IO.Ports.SerialPort]::new($Port,115200,[IO.Ports.Parity]::None,8,[IO.Ports.StopBits]::One)
            $capturePort.DtrEnable=$false;$capturePort.RtsEnable=$false
            $capturePort.Handshake=[IO.Ports.Handshake]::None
            $capturePort.ReadBufferSize=65536;$capturePort.ReadTimeout=200
            $capturePort.Open()
            ++$captureMeta.connections;$captureMeta.state='recording';$captureLastError=''
            Open-CaptureSegment
            Add-CaptureEvent 'connected' $Port;Save-CaptureStatus
            Write-Output ('CONNECTED RX ONLY '+$Port)
            while(-not(Test-Path -LiteralPath $captureStop)) {
                $captureWaiting=$capturePort.BytesToRead
                if($captureWaiting -gt 0) {
                    $captureCount=$capturePort.Read($captureBuffer,0,[Math]::Min($captureWaiting,$captureBuffer.Length))
                    $captureData.Write($captureBuffer,0,$captureCount)
                    $captureTimes.WriteLine(('{0},{1},{2},{3},{4},{5}' -f [DateTime]::UtcNow.ToString('o'),$captureClock.ElapsedMilliseconds,$captureSegment,$captureSegmentOffset,$captureMeta.bytes,$captureCount))
                    $captureSegmentOffset+=$captureCount;$captureMeta.bytes+=$captureCount
                } else {Start-Sleep -Milliseconds 10}
                if($captureClock.ElapsedMilliseconds-$captureLastFlush -ge 200) {
                    $captureData.Flush();$captureTimes.Flush();$captureLastFlush=$captureClock.ElapsedMilliseconds
                }
                if($captureClock.ElapsedMilliseconds-$captureLastStatus -ge 1000) {
                    $captureMeta.updated_utc=[DateTime]::UtcNow.ToString('o');Save-CaptureStatus
                    $captureLastStatus=$captureClock.ElapsedMilliseconds
                }
                if($captureClock.ElapsedMilliseconds-$captureSegmentStarted -ge 1800000){Open-CaptureSegment}
            }
        } catch {
            $captureMeta.state='waiting_for_port'
            $captureMessage=$_.Exception.Message
            if($captureMessage -ne $captureLastError){Add-CaptureEvent 'connection_or_io_error' $captureMessage;$captureLastError=$captureMessage}
            $captureMeta.last_error=$captureMessage;Save-CaptureStatus
        } finally {
            Close-CaptureSegment
            if($capturePort){if($capturePort.IsOpen){$capturePort.Close()};$capturePort.Dispose();$capturePort=$null}
        }
        if(-not(Test-Path -LiteralPath $captureStop)){Start-Sleep -Milliseconds 500}
    }
    $captureMeta.state='closed';$captureMeta.ended_utc=[DateTime]::UtcNow.ToString('o')
    Add-CaptureEvent 'closed' 'STOP requested';Save-CaptureStatus
} finally {
    $captureTimes.Dispose();$captureEvents.Dispose()
}
